﻿0. feladatrész:

A megvalósítandó program egy Névjegyzék lesz

A Névjegyzék C# nyelvben megvalósított program így a legelterjedtebb operációs rendszereken
használható, mint például a Windows. A felhasználóbarát program képes névjegyek tárolására,
amiket .txt kiterjesztésben olvasható formában kiexportálhat. Kész sablont is képes megnyitni
akár a program által mentett vagy ugyanabban a struktúrában felépítet .txt kiterjesztésű fájlt.

Program leírása

A megvalósult program valóban egy névjegyzék lett, mely a partner kéréseit teljesíti:
  * UWP felület, XAML kód található benne
  * A program használ ItemControlt és DataTemplatet
  * Legalább 5 különböző UI elem található benne (TextBox, TextBlock, Button, Rectangle, StackPanel, Grid)
    * A kényelmes felhasználás érdekében scrollbar is elhelyezésre került
  * Az adatok databinding segítségével vándorolnak
  * Linq használatával tetszőleges usert kikereshetünk Neptun kód alapján

  Felépítés

    * A Model mappában található az alap Item, ami egy adott Person tulajdonságaival bír: Név, Kapcsolat, Neptun kód
	* A ViewModel mappában található az a lista, ami a Névjegyzékben található Personokat tartalmazza
	* A megjelenítés a View mappában található.
	 * A userfriendly megközelítés szempontjából 2 ablakra oszlik a UI:
	  * Person: Ezen a felületen lehet felvinni az adatokat illetve keresni Neptun kód alapján
	  * List: Ezen a felületen listázódnak ki az adatok
  
  Használat

    * A használat rendkívül egyszerű, kézikönyv se kell hozzá, minden a user keze alatt van.
	* A mezők értelemszerű kitöltésével és a gombok megnyomásával a fent említett funkciók életbelépnek.
	* Így játszi könnyedséggel lehet bővíteni a személyes névjegyzékünket.

