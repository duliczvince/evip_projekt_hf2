"# hf2-l1_czarthduliczolah" 

A csapat tagai:
Dulicz Vince
Ol�h Zsolt
Cz�rth Csan�d

Vide�: https://www.loom.com/share/36718c5f260a49c3bd7117e401a629f0
