﻿using hf2.Model;
using hf2.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Xml.Serialization;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace hf2.View
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class List : UserControl
    {
        public List()
        {
            this.InitializeComponent();
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            var picker = new Windows.Storage.Pickers.FileOpenPicker();
            picker.ViewMode = Windows.Storage.Pickers.PickerViewMode.Thumbnail;
            picker.SuggestedStartLocation = Windows.Storage.Pickers.PickerLocationId.PicturesLibrary;
            picker.FileTypeFilter.Add(".txt");

            Windows.Storage.StorageFile file = await picker.PickSingleFileAsync();
            if (file != null)
            {
                var msgDialog = new MessageDialog("Fájl megnyitva!");
                await msgDialog.ShowAsync();

                using (var inputStream = await file.OpenReadAsync())
                using (var classicStream = inputStream.AsStreamForRead())
                using (var streamReader = new StreamReader(classicStream))
                {
                    while (streamReader.Peek() >= 0)
                    {
                        string line = streamReader.ReadLine();

                        string[] tmp = line.Split(',');

                        string Type = SplitLinesFromTxt(tmp[0]);
                        string Name = SplitLinesFromTxt(tmp[1]);
                        string Neptun = SplitLinesFromTxt(tmp[2]);

                        MainPageViewModel.PersonList.Add(new Item()
                        {
                            Type = Type,
                            Names = Name,
                            Code = Neptun
                        });
                    }
                }
            }
        }

        private string SplitLinesFromTxt(string waitingForSplit)
        {
            string[] tmp = waitingForSplit.Split(':');
            return tmp[1];
        }
    }
}
