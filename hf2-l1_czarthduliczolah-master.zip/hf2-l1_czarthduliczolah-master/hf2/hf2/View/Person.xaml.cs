﻿using hf2.Model;
using hf2.ViewModels;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Xml;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace hf2.View
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class Person : UserControl
    {
        public Person()
        {
            this.InitializeComponent();
        }
        private void Button_Click_Hozzaad(object sender, RoutedEventArgs e)
        {
            if(!Name.Text.Equals(""))
            {
                MainPageViewModel.PersonList.Add(new Item()
                {
                    Type = Typ.Text,
                    Names = Name.Text,
                    Code = Neptun.Text
                });

                Typ.Text = "";
                Name.Text = "";
                Neptun.Text = "";
            }
        }

        private async void Button_Click_Ment(object sender, RoutedEventArgs e)
        {
            var savePicker = new Windows.Storage.Pickers.FileSavePicker();
            savePicker.SuggestedStartLocation = Windows.Storage.Pickers.PickerLocationId.DocumentsLibrary;
            savePicker.FileTypeChoices.Add("Plain Text", new List<string>() { ".txt" });
            savePicker.SuggestedFileName = "nevjegyzek_[dilit_dis]";

            Windows.Storage.StorageFile file = await savePicker.PickSaveFileAsync();

            if (file != null)
            {
                Windows.Storage.CachedFileManager.DeferUpdates(file);

                string saveData = "";
                for (int i = 0; i < MainPageViewModel.PersonList.Count; i++)
                {
                    string Typ = MainPageViewModel.PersonList[i].Type;
                    string Name = MainPageViewModel.PersonList[i].Names;
                    string Neptun = MainPageViewModel.PersonList[i].Code;

                    saveData = "ism:" + Typ + "," + "név:" + Name + "," + "neptun:" + Neptun + "\n";
                    
                    await Windows.Storage.FileIO.AppendTextAsync(file, saveData);
                }
                
                Windows.Storage.Provider.FileUpdateStatus status = await Windows.Storage.CachedFileManager.CompleteUpdatesAsync(file);                
                if (status == Windows.Storage.Provider.FileUpdateStatus.Complete)
                {
                    var msgDialog = new MessageDialog("Fájl mentve!");
                    await msgDialog.ShowAsync();
                }
                else
                {
                    var msgDialog = new MessageDialog("Sikertelen mentés!");
                    await msgDialog.ShowAsync();
                }
            }
        }

        private void Button_Click_Keres(object sender, RoutedEventArgs e)
        {
            var items =
                from item in MainPageViewModel.PersonList
                where item.Code == KNeptun.Text
                select item.Names + "\n" + item.Type + "\n" + item.Code;

            try
            {
                MainPageViewModel.PersonListk.Add(new Item()
                {
                    CodeKeres = items.First().ToString()
                });
            }
            catch (Exception) {
                MainPageViewModel.PersonListk.Add(new Item()
                {
                    CodeKeres = "Hibás Neptun!"
                });
            }

            
        }
    }
}
