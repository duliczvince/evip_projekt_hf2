﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hf2.Model
{
    public class Item
    {
        public string Type { get; set; }
        public string Names { get; set; }
        public string Code { get; set; }
        public string CodeKeres { get; set; }
    }
}
